package com.example.silent_ver_1.ui.syncoptions;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.silent_ver_1.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FilterEditMessage extends AppCompatActivity {
    String currUser;
    EditText msg;
    private RecyclerView recyclerView;
    private Button saveBtn;
    private Button delBtn;
    private int curPosition = -1;
    public static ArrayList<FiltertModel> arrayList = new ArrayList<>();
    private FilterAdapter adapter;
    public static final String TAG = "ContentValues";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currUser = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
        setContentView(R.layout.activity_filter_edit_message);
        msg = findViewById(R.id.editFilterTwo);
        recyclerView = findViewById(R.id.recyclerViewFilter);
        saveBtn = findViewById(R.id.buttonFilter);
        delBtn = findViewById(R.id.deleteBtn);
        getFilterList();

    }

    private void getFilterList() {
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://silent-android-application-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference myRef = database.getReference(currUser+"/agc");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                arrayList.clear();
                for(DataSnapshot d : snapshot.getChildren()){
                    if(d.exists()){
//                        Log.i(TAG,"Try again current d: " + d.getKey());
                        FiltertModel t = d.getValue(FiltertModel.class);
//                        Log.i(TAG,"Try again " + t.getFilter());
                        FilterEditMessage.arrayList.add(t);
                    }
                }
                FilterEditMessage.this.updateRe();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        FilterEditMessage.this.updateRe();
    }

    public void updateRe(){
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new FilterAdapter(this, FilterEditMessage.arrayList);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new FilterAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                msg.setText(arrayList.get(position).getFilter());
                curPosition = position;
            }
        });
    }

    public void onSaveClickFilter(View view) {
        // We need to talk with the user holder for this
        String s = msg.getText().toString();
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://silent-android-application-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference myRef = database.getReference(currUser+"/agc").push();
        DatabaseReference ref = database.getReference(currUser).child("agc");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot temp: snapshot.getChildren()){
                    FiltertModel f = temp.getValue(FiltertModel.class);
                    if(f.getFilter().equals(s)){
                        return;
                    }
                }
                FiltertModel temp = new FiltertModel(s);
                myRef.setValue(temp);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
//        FiltertModel temp = new FiltertModel(s);
//        myRef.setValue(temp);
    }

    public void onClickDel(View view) {
        String s = msg.getText().toString();
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://silent-android-application-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference myRef = database.getReference(currUser);
        for(FiltertModel f : arrayList){
            if(f.getFilter().equals(s)){
                arrayList.remove(f);
                Query query = myRef.child("/agc").orderByChild("filter").equalTo(s);
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot snap: dataSnapshot.getChildren()) {
                            snap.getRef().removeValue();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.e(TAG, "onCancelled", databaseError.toException());
                    }
                });
                break;
            }
        }
    }
}